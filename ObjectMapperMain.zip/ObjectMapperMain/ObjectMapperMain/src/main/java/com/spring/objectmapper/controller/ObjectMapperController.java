package com.spring.objectmapper.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.objectmapper.utility.JavaToJson;
import com.spring.objectmapper.utility.JsonArrayToJavaList;
import com.spring.objectmapper.utility.JsonToJacsonJsonNode;
import com.spring.objectmapper.utility.JsonToJava;

@RestController
@RequestMapping("/test")
public class ObjectMapperController {
	@Autowired
	JavaToJson javaToJson;
	@Autowired 
	JsonToJava jsonToJava;
	@Autowired
	JsonToJacsonJsonNode jsonToJacsonJsonNode;
	@Autowired
	JsonArrayToJavaList jsonArrayToJavaList;
	
	@RequestMapping("/javaToJson")
	public void javaToJson() {
		javaToJson.convertJavaToJson();
	}
	
	@RequestMapping("/jsonToJava")
	public void jsonToJava() {
		jsonToJava.jsonToJava();
	}
	
	@RequestMapping("/jsonToJsonNode")
	public void jsonToJsonNode() {
		jsonToJacsonJsonNode.jsonToJacsonNode();
	}
	
	@RequestMapping("/jsonArrayToJavaList")
	public void jsonArrayToJavaList() {
		jsonArrayToJavaList.jsonArrayToJavaList();
	}
}
