package com.spring.objectmapper.utility;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JsonToJacsonJsonNode {
	
	public void jsonToJacsonNode() {
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode jsonNode = mapper.readTree(new File("target/employee.json"));
			System.out.println("Id : "+jsonNode.get("id").asText());
		} catch(IOException ioe) {
			System.out.println(ioe.getMessage());
		}
	}
}
