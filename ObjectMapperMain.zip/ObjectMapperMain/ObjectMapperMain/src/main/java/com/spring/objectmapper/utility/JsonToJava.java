package com.spring.objectmapper.utility;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.objectmapper.pojo.Employee;

@Component
public class JsonToJava {
	public void jsonToJava() {
		ObjectMapper mapper = new ObjectMapper();
		try {
			Employee employee = mapper.readValue(new File("target/employee.json"), Employee.class);
			System.out.println(employee.toString());
		} catch(IOException ioe) {
			System.out.println(ioe.getMessage());
		}
	}
}
