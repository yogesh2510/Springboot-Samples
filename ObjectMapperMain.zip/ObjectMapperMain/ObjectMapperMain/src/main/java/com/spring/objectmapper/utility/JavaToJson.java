package com.spring.objectmapper.utility;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.objectmapper.pojo.Employee;

@Component
public class JavaToJson {
	
	Employee[] employee = new Employee[5] ;
	public void convertJavaToJson() {
		ObjectMapper mapper = new ObjectMapper();
		File empFile = new File("target/employee.json");
		for(int i = 0; i < 5; i++) {
			employee[i] = new Employee("10"+i, "OBJ_"+i);

			try {
				mapper.writeValue(empFile, employee);
			} catch(IOException ie) {
				System.out.println(ie.getMessage());
			}
		}
	}
}
