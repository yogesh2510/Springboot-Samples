package com.spring.objectmapper.utility;

import java.io.File;
import java.util.Map;

import org.springframework.asm.TypeReference;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JsonToJavaMap {
	public void  jsonToJavaMap() throws Exception{
		ObjectMapper mapper = new ObjectMapper();
	}
}
