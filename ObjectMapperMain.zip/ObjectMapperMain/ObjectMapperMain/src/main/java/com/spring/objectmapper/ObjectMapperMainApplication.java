package com.spring.objectmapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObjectMapperMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObjectMapperMainApplication.class, args);
	}

}
