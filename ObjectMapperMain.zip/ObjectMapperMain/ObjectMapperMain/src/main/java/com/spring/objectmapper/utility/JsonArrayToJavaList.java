package com.spring.objectmapper.utility;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.objectmapper.pojo.Employee;

public class JsonArrayToJavaList {

	public void jsonArrayToJavaList() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			mapper.readValue(new File("target/employee.json"), Employee.class);
		} catch(JsonMappingException jme) {
			
		} catch(JsonParseException jpe) {
			
		} catch(IOException ioe) {
			
		}
	}

}
